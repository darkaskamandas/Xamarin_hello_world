﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace SWU
{
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        bool clickBtn = true;
        public MainPage()
        {
            InitializeComponent();
        }
        private void btn_Clicked(object sender, EventArgs e)
        {
            if(clickBtn)
            {
                clickBtn = false;
                btn.Text = "Hi";
                tbResult.Text = "Hello, world!";
                tbResult.BackgroundColor = Color.Bisque;
            }
            else
            {
                clickBtn = true;
                btn.Text = "Bye";
                tbResult.Text = "Goodbye, world!";
                tbResult.BackgroundColor = Color.Silver;
            }
        }
    }
}
